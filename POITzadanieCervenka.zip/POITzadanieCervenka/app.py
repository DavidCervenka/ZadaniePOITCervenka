from threading import Lock
from flask import Flask, render_template, session, request, jsonify, url_for
from flask_socketio import SocketIO, emit, disconnect
import time
import random
import serial
import math
import json
import mysql.connector
import configparser as ConfigParser
import re
async_mode = None

config = ConfigParser.ConfigParser()
config.read('config.cfg')
myhost = config.get('mysqlDB', 'host')
myuser = config.get('mysqlDB', 'user')
mypasswd = config.get('mysqlDB', 'passwd')
mydb = config.get('mysqlDB', 'db')
print(myhost)

app = Flask(__name__)

app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app, async_mode=async_mode)
thread = None
generating = False
thread_lock = Lock()

arduino_serial = serial.Serial('/dev/ttyACM0', 9600)
vzdialenost=0
stav_brany=0
zapisane=False
data_values = []
binary_values = []

def background_thread(args):
    #global vzdialenost,stav_brany,vzdialenosti,stavy_bran,zapisane
    global data_values, binary_values, data, binary_data, count
    count = 0

    while True:
      if generating:
            data = arduino_serial.readline().decode().strip()
            
            
            
            #matches = re.search(r'Vzdialenost od rampy: (\d+) cm,  Brana: (\w+)', data)

            #if matches:
                #vzdialenost = int(matches.group(1))
                #if matches.group(2).lower() == "zatvorena":
                    #stav_brany = "Zatvorena"
                #else:
                    #stav_brany = "Otvorena"

                #vzdialenosti.append(vzdialenost)
                #stavy_bran.append(stav_brany)
                
                
                
                
                
                
                
                
            socketio.sleep(2)
            count += 1
            binary_data = int(float(data))
            if binary_data >= 40:   
                binary_data = 0 
            else:
                binary_data = 1
            binary_data = str(int(binary_data))
            data_values.append(data)
            binary_values.append(binary_data)
            print("Vzdialenost:", data)
            print("Stav brány:", binary_data)

            #socketio.sleep(0.01)
            count += 1
            socketio.emit('my_response',
                {'data': data, 'binary_data': binary_data,'count': count},
                    namespace='/test')

@app.route('/write')
def write2file():
    global data_values, binary_values, count
    pocitadlo=0
    data = []
    for idx, (current_data, binary_data) in enumerate(zip(data_values, binary_values), start=1):
        pocitadlo +=1
        val = {'VZDIALENOST cm': current_data , 'STAV RAMPY': binary_data, 'PREPOCET': pocitadlo,}
        data.append(val)

    with open("static/files/test.txt", "a+") as fo:
        fo.write(json.dumps(data) + '\n')

    data_values = []
    binary_values = []

    return "done"


@app.route('/')
def index():
    return render_template('index.html', async_mode=socketio.async_mode)

@app.route('/gauge', methods=['GET', 'POST'])
def gauge():
    return render_template('gauge.html', async_mode=socketio.async_mode)

@app.route('/graphlive', methods=['GET', 'POST'])
def graphlive():
    return render_template('graphlive3.html', async_mode=socketio.async_mode)

@app.route('/graph', methods=['GET', 'POST'])
def graph():
    return render_template('graph.html', async_mode=socketio.async_mode)

@socketio.on('my_event', namespace='/test')
def test_message(message):
    session['receive_count'] = session.get('receive_count', 0) + 1
    session['A'] = message['value']
    emit('my_response',
         {'data': message['value'], 'count': session['receive_count']})
 
@socketio.on('disconnect_request', namespace='/test')
def disconnect_request():
    session['receive_count'] = session.get('receive_count', 0) + 1
    emit('my_response',
         {'data': 'Disconnected!', 'count': session['receive_count']})
    disconnect()


@app.route('/db')
def db():
    db_connection = mysql.connector.connect(host=myhost, user=myuser, passwd=mypasswd, db=mydb)
    cursor = db_connection.cursor()
    cursor.execute('''SELECT id, data, binary_data, created_at FROM logs''')
    rv = cursor.fetchall()
    cursor.close()
    db_connection.close()

    data = []
    for row in rv:
        data.append({
            "id": row[0],
            "data": row[1],
            "binary_data": row[2],
            "created_at": row[3].strftime("%Y-%m-%d %H:%M:%S")
        })

    return jsonify(data)
    
    
    

@socketio.on('connect', namespace='/test')
def test_connect():
    global thread
    with thread_lock:
        if thread is None:
            thread = socketio.start_background_task(target=background_thread, args=session._get_current_object())
    emit('my_response', {'data': 'Connected', 'count': 0})

@socketio.on('disconnect', namespace='/test')
def test_disconnect():
    print('Client disconnected', request.sid)

@socketio.on('start_generation', namespace='/test')
def start_generation():
    global generating
    generating = True

@socketio.on('stop_generation', namespace='/test')
def stop_generation():
    #global generating,vzdialenosti,stavy_bran,data
    global data_values, binary_values, generating, data
    generating = False

    vzdialenosti_json=json.dumps(data_values)
    stavy_bran_json=json.dumps(binary_values)
    db_connection = mysql.connector.connect(host=myhost, user=myuser, passwd=mypasswd, db=mydb)
    cursor = db_connection.cursor()
    #cursor.execute('''INSERT INTO udaje (vzdialenost,stav_brany) VALUES (%s,%s)''', (vzdialenosti_json,stavy_bran_json))
    cursor.execute('''INSERT INTO logs (data,binary_data) VALUES (%s,%s)''', (vzdialenosti_json,stavy_bran_json))
    db_connection.commit()
    print('Data added successfully!')
    data_values=[]
    binary_values=[]

    data=0

if __name__ == '__main__':
    socketio.run(app, host="0.0.0.0", port=80, debug=True)
